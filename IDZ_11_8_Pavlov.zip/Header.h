#pragma once
#ifndef _HEADER_H_
#define _HEADER_H_
double squareTriangle(double x1, double y1, double x2, double y2, double x3, double y3);
double squareRectangle(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4);
double squareParallelogram(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4);
double squareRhomb(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4);
double squareTrapeze(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4);
double squareCircle(double r);
double squareCircleSector(double r, double alpha);
#endif 