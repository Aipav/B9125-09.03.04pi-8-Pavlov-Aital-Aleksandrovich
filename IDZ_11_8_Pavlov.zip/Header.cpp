#include <iostream>
#include <cmath>
#include "Header.h"
using namespace std;

double squareTriangle(double x1, double y1, double x2, double y2, double x3, double y3)
{
    double result = fabs((x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1)) / 2;
    return result;
}
double squareRectangle(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4) {
    double a = sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
    double b = sqrt((x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2));
    return a*b;
}
double squareParallelogram(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4) {    
    double result = fabs((x2 - x1) * (y4 - y1) - (y2 - y1) * (x4 - x1));
    return result;
}
double squareRhomb(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4) {
    double result = 0.5 * fabs((x1 * y2) + (x2 * y3) + (x3 * y4) + (x4 * y1) - (y1 * x2) - (y2 * x3) - (y3 * x4) - (y4 * x1));
    return result;
}
double squareTrapeze(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4) {
    double result = 0.5 * fabs((x1 * y2) + (x2 * y3) + (x3 * y4) + (x4 * y1) - (y1 * x2) - (y2 * x3) - (y3 * x4) - (y4 * x1));
    return result;
}
double squareCircle(double r) {
    double result = 3.14159 * (r * r);
    return result;
}
double squareCircleSector(double r, double alpha) {
    double result = (3.1415 * (r * r) * alpha) / 360;
    return result;
}